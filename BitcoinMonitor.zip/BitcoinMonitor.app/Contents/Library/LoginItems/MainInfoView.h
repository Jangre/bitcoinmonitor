//
// Created by jag on 3/24/13.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>
#import "FlippedView.h"

@class DataDepth;
@class DataTicker;
@class DataTrades;


@interface MainInfoView : FlippedView

- (void)didUpdateDepth:(DataDepth *)depth;
- (void)didUpdateTicker:(DataTicker *)ticker;
- (void)didUpdateTrades:(DataTrades *)data;
- (void)updateUI;

@end