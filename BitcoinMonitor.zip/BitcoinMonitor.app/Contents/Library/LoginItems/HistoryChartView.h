//
// Created by jag on 3/25/13.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>

@class DataTrades;


@interface HistoryChartView : NSView

- (void)didUpdateTrades:(DataTrades *)indata;
@property int selectedTimespan;
@end