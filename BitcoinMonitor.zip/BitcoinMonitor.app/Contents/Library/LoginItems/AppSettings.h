//
// Created by jag on 3/24/13.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>
#import <ServiceManagement/ServiceManagement.h>


@interface AppSettings : NSObject


+ (BOOL) applicationWillStartAtLogin;
+ (void) setStartAtLogin:(BOOL)enabled;
+ (AppSettings*)getSettings;
+ (NSString*)symbolForCurrency:(NSString*)c;
- (void) save;

@property float fontSize;
@property float numDecimals;
@property NSString* currency; /* USD, EUR etc */
@property BOOL backgroundIndicator;

@end