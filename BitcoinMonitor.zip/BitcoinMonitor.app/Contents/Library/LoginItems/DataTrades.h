//
// Created by jag on 3/25/13.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>


@interface DataTrades : NSObject

@property NSMutableDictionary *dictTrades;
@property NSMutableArray     *arrChartPoints;
@property float     chartLow;
@property float     chartHigh;

-(void)addTrade:(double)date price:(float)price;
-(void)makeChartData:(double)timespan;
-(float)percentageChangeInTimeSpan:(double)timespan;
-(void)removeAllData;

@end